const API_URL = 'https://dummyjson.com/products?limit=9';

const listaProdutos = document.querySelector('#listaProdutos');
const statusApi = document.querySelector('#statusApi');
const busca = document.querySelector('#busca');
const contadorCarrinho = document.querySelector('#contadorCarrinho');
const listaCarrinho = document.querySelector('#listaCarrinho');
const totalCarrinho = document.querySelector('#totalCarrinho');
const btnAtualizar = document.querySelector('#btnAtualizar');
const btnFinalizar = document.querySelector('#btnFinalizar');
const mensagemCompra = document.querySelector('#mensagemCompra');
const formContato = document.querySelector('#formContato');
const mensagemFormulario = document.querySelector('#mensagemFormulario');

let produtos = [];
let carrinho = [];

async function carregarProdutos() {
  statusApi.textContent = 'Carregando produtos...';
  listaProdutos.innerHTML = '';

  try {
    const resposta = await fetch(API_URL);

    if (!resposta.ok) {
      throw new Error(`Erro HTTP: ${resposta.status}`);
    }

    const dados = await resposta.json();

    produtos = dados.products;

    renderizarProdutos(produtos);

    statusApi.textContent = 'Produtos carregados com sucesso.';
  } catch (erro) {
    statusApi.textContent = 'Erro ao carregar produtos.';
    console.error('Erro ao carregar produtos:', erro);
  }
}

function renderizarProdutos(lista) {
  listaProdutos.innerHTML = '';

  if (lista.length === 0) {
    listaProdutos.innerHTML = '<p>Nenhum produto encontrado.</p>';
    return;
  }

  lista.forEach((produto) => {
    const card = document.createElement('article');

    card.className = 'produto-card';

    card.innerHTML = `
      <img src="${produto.thumbnail}" alt="${produto.title}" />

      <h3>${produto.title}</h3>

      <p class="descricao">
        ${produto.description}
      </p>

      <p class="preco">
        R$ ${produto.price}
      </p>

      <button
        class="botao-secundario"
        onclick="adicionarCarrinho(${produto.id})"
      >
        Adicionar ao carrinho
      </button>
    `;

    listaProdutos.appendChild(card);
  });
}

function adicionarCarrinho(idProduto) {
  const produto = produtos.find((item) => item.id === idProduto);

  if (!produto) {
    mensagemCompra.textContent = 'Produto não encontrado.';
    mensagemCompra.classList.add('erro');
    return;
  }

  carrinho.push(produto);

  mensagemCompra.textContent = 'Produto adicionado ao carrinho.';
  mensagemCompra.classList.remove('erro');

  atualizarCarrinho();
}

function atualizarCarrinho() {
  listaCarrinho.innerHTML = '';

  carrinho.forEach((produto) => {
    const item = document.createElement('li');

    item.textContent = `${produto.title} - R$ ${produto.price}`;

    listaCarrinho.appendChild(item);
  });

  contadorCarrinho.textContent = carrinho.length;

  const total = carrinho.reduce((soma, produto) => {
    return soma + produto.price;
  }, 0);

  totalCarrinho.textContent = total
    .toFixed(2)
    .replace('.', ',');
}

busca.addEventListener('input', () => {
  const termo = busca.value.toLowerCase().trim();

  const filtrados = produtos.filter((produto) => {
    return produto.title.toLowerCase().includes(termo);
  });

  renderizarProdutos(filtrados);
});

btnAtualizar.addEventListener('click', carregarProdutos);

btnFinalizar.addEventListener('click', () => {
  mensagemCompra.classList.remove('erro');

  if (carrinho.length === 0) {
    mensagemCompra.textContent =
      'Adicione produtos ao carrinho antes de finalizar.';
    mensagemCompra.classList.add('erro');
    return;
  }

  mensagemCompra.textContent = 'Compra finalizada com sucesso!';

  carrinho = [];

  atualizarCarrinho();
});

formContato.addEventListener('submit', (evento) => {
  evento.preventDefault();

  const nome = document.querySelector('#nome').value.trim();
  const email = document.querySelector('#email').value.trim();
  const curso = document.querySelector('#curso').value;
  const termos = document.querySelector('#termos').checked;

  mensagemFormulario.classList.remove('erro');

  if (nome.length < 3) {
    mensagemFormulario.textContent = 'Informe um nome válido.';
    mensagemFormulario.classList.add('erro');
    return;
  }

  if (!email.includes('@') || !email.includes('.')) {
    mensagemFormulario.textContent = 'Informe um e-mail válido.';
    mensagemFormulario.classList.add('erro');
    return;
  }

  if (curso === '') {
    mensagemFormulario.textContent = 'Selecione um curso.';
    mensagemFormulario.classList.add('erro');
    return;
  }

  if (!termos) {
    mensagemFormulario.textContent = 'Você precisa aceitar os termos.';
    mensagemFormulario.classList.add('erro');
    return;
  }

  mensagemFormulario.textContent = 'Solicitação enviada com sucesso!';

  formContato.reset();
});

carregarProdutos();